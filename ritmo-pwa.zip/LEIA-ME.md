# Ritmo — instalar no iPhone

Arquivos: index.html, manifest.json, sw.js e 4 ícones PNG. Mantenha todos na MESMA pasta.

1. Coloque a pasta num endereço https (ex.: GitHub Pages ou Netlify Drop).
2. No iPhone, abra o endereço no SAFARI.
3. Compartilhar → Adicionar à Tela de Início → Adicionar.
4. Abra sempre pelo ícone da Tela de Início.

Seus dados ficam só no aparelho. Use Mais → Meus dados → Exportar backup de vez em quando.
Não mude o endereço depois de instalar (os dados são ligados ao endereço).
